from distutils.core import setup

setup(
  name        = "print_list",
  version     = "1.0.0",
  py_modules  = ['print_list'],
  author      = 'NewBie',
  author_email= 'hfpython@headfirstlabs.com',
  url         = 'http://www.headfirstlabs.com',
  description = 'A simple print module for nested lists',
)
